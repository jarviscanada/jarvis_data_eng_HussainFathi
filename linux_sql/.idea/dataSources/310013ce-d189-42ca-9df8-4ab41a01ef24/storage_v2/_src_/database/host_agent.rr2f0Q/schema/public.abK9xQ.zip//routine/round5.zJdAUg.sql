create function round5(ts timestamp without time zone) returns timestamp without time zone
    language plpgsql
as
$$
BEGIN
    RETURN date_trunc('hour', ts) + date_part('minute', ts):: int / 5 * interval '5 min';
END;
$$;

alter function round5(timestamp) owner to postgres;

